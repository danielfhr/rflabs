package lab7_3143B;

@SuppressWarnings("serial")
public class USVInputFileCustomException extends Exception {

    public USVInputFileCustomException(String message) {
        super(message);
    }

}