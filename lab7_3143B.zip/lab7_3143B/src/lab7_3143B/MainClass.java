package lab7_3143B;

import java.util.ArrayList;
import java.util.List;

import lab7_3143B.DistanceUtils;
import lab7_3143B.FileUtils;

@SuppressWarnings("unused")
public class MainClass {

	public static <string> void main(String[] args) {
		String[][] learningSet;
		try {
			learningSet = FileUtils.readLearningSetFromFile("in.txt");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length;
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns,
					numberOfFeatures));
			
			List<String> classesList = new ArrayList<String>();
			for(int i=0; i<numberOfPatterns; i++)
			{
				String clazz = learningSet[i][learningSet[i].length-1];
				if(!classesList.contains(clazz))
				{
					classesList.add(clazz);
				}
			}
			for(int j=0; j<classesList.size(); j++)
			{
				System.out.println(classesList.get(j) + " ");
			}
			
			double[][]wMatrix = new double[classesList.size()][numberOfFeatures+1];
			for(int i=0; i<wMatrix.length; i++)
			{
				double freeTermSum = 0.0;
				for(int j=0; j<wMatrix[i].length;j++)
				{
					double featureSum = 0.0;
					int featureMembers = 0;
					for(int i2=0; i2<numberOfPatterns; i2++)
					{
						if(learningSet[i2][learningSet[i2].length-1].equals(classesList.get(i)))
						{
							featureSum += Double.valueOf(learningSet[i2][j]);
							featureMembers ++;
						}
					}
					wMatrix[i][j] = featureSum/featureMembers;
					freeTermSum += Math.pow(wMatrix[i][j], 2);
				}
				wMatrix[i][wMatrix[i].length-1] =- 0.5* freeTermSum;
			}
			System.out.println();
			for(int i = 0; i<wMatrix.length;i++)
			{
				for(int j=0; j<wMatrix[0].length;j++)
				{
					System.out.println(wMatrix[i][j] + " ");
					
				}
				System.out.println();
			}
			
			/*double[] classesArray = new double[numberOfPatterns];
			for(int i=0;i<numberOfPatterns;i++)
			{
				String clazz = learningSet[i][learningSet[i].length-1];
				boolean exists = false;
				int lastPopulatePosition = 0;
				for(int j=0; j<classesArray.length;j++)
				{
					if(classesArray[j].equals(clazz))
					{
						exists = true;
					}
					if(classesArray[j]!=0)
					{
						lastPopulatePosition=j;
					}
				}
				if(!exists)
				{
					classesArray[lastPopulatePosition+1]= clazz;
				}
			}
			for(int j=0;j<classesArray.length;j++)
			{
				System.out.println(classesArray[j] + " ");
				
			}*/
			
			/*for( int patternNr=1; patternNr<3;patternNr++)
			{
			 double[][] newPatterns= initPatterns();
			 double[][] distance= new double [newPatterns.length][numberOfPatterns];
			 
			 for(int i=0;i<newPatterns.length;i++)
			 {
				 for(int j=0 ; j < numberOfPatterns ; j++)
				 {
					 distance[i][j]=DistanceUtils.calculateSimpleEuclidianDistanceNN(newPatterns[i], learningSet[j]);
			 
					 double euclidianDistance=DistanceUtils.calculateSimpleEuclidianDistanceNN(newPatterns[i], learningSet[patternNr]);
					 System.out.println("Euclidian distance between first pattern and pattern" +patternNr+ " is:"+ euclidianDistance);
			
				 	}
			 	}
			}
			
			/*double[] distanceMatrix = DistanceUtils.calculateDistanceMatrix(learningSet);
			int searchedPattern = numberOfPatterns-1;
			int closestPattern = 0;
			double[] distanceRow = distanceMatrix[searchedPattern];
			double minDistance = distanceRow[0];
			for(int i=0;i<distanceRow.length;i++)
			{
				if (distanceRow[i] < minDistance && i!=searchedPattern)
				{
					minDistance = distanceRow[i];
					closestPattern = i;
				}
			}*/
			//System.out.println(String.format("Closest pattern is %s", closestPattern));
			//int classColum = learningSet[closestPattern].length-1;
			//System.out.println(String.format("Closest class is %s", learningSet[closestPattern][classColum]));
			//for(int patternNR=1; patternNR<numberOfPatterns; patternNR++) {
				//double euclianDistance = DistanceUtils.calculateSimpleEuclidianDistance(learningSet[0], learningSet[patternNR]); 
				//System.out.println("The euclidian distance between first pattern an second pattern is: " +patternNR+ " is " +euclianDistance);
				//double cebisevDistance = DistanceUtils.calculateSimpleCebisevDistance(learningSet[0], learningSet[patternNR]); 
				//System.out.println("The Cebisev distance between first pattern an second pattern is: " +patternNR+ " is " +cebisevDistance);
				//double cityblockDistance = DistanceUtils.calculateCityBlockDistance(learningSet[0], learningSet[patternNR]); 
				//System.out.println("The CityBlock distance between first pattern an second pattern is: " +patternNR+ " is " +cityblockDistance);
				//double MahalanobisDistance = DistanceUtils.calculateMahalanobisDistance(learningSet[0], learningSet[patternNR], numberOfPatterns); 
				//System.out.println("The Mahalanobis distance between first pattern an second pattern is: " +patternNR+ " is " +MahalanobisDistance);
			//}

		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
	}
	 /*public static double[][] initPatterns(){
		 double[][] newPatterns= new double[3][2];
		 newPatterns[0][0]=25.89;
		 newPatterns[0][1]=47.56;
		 newPatterns[1][0]=24;
		 newPatterns[1][1]=45.15;
		 newPatterns[2][0]=25.33;
		 newPatterns[2][1]=45.44;
		 
		 return newPatterns;
		 }*/
	}





	

