package lab7_3143B;

public class DistanceUtils {

	protected static double calculateSimpleEuclidianDistance(double pattern1[], double pattern2[]) {
		double distance = 0.0;
		for(int feature=0;feature<pattern1.length-1;feature++) {
			distance+=Math.pow(pattern1[feature] - pattern2[feature], 2);
		}
		
		//return Math.sqrt(distance);//v1
		return Math.floor(Math.sqrt(distance)*100)/100; //v2
		
	}
	
	//Lab 5
	
	protected static double calculateSimpleEuclidianDistanceNN(double[] pattern1, String pattern2[]) {
		double distance = 0.0;
		for (int feature = 0; feature < 2; feature++) {
			distance += Math.pow(pattern1[feature] - Double.valueOf(pattern2[feature]), 2);
		}
		return Math.floor(Math.sqrt(distance))*10000/10000;
	}
	
	protected static double[][] calculateDistanceMatrix(double[][] learningSet)
	{
		int numberofPatterns = learningSet.length;
		double[][] distanceMatrix = new double[numberofPatterns][numberofPatterns];
		for(int i=0; i < numberofPatterns; i++)
		{
			//for(int j = 0; j < numberofPatterns; j++) //v1
			for(int j = i+1; j < numberofPatterns; j++) //v2
			{
				distanceMatrix[i][j] = calculateSimpleEuclidianDistance(learningSet[i],learningSet[j]);
				distanceMatrix[j][i] = distanceMatrix[i][j];
			}
		}
		for(int i = 0; i< numberofPatterns; i++)
		{
			for(int j=0; j< numberofPatterns; j++)
			{
				System.out.print(distanceMatrix[i][j] + " ");
			}
			System.out.println();
		}
		return distanceMatrix;
	}
	
	protected static double calculateSimpleCebisevDistance(double pattern1[], double pattern2[]) {
		double distance = 0.0;
		for(int feature = 0; feature<pattern1.length;feature++) {
			double currentValue = Math.abs(pattern1[feature] - pattern2[feature]);
			if(currentValue > distance) {
				distance = currentValue;
			}
		}
		return distance;
	}
	protected static double calculateCityBlockDistance(double pattern1[], double pattern2[]) {
		double distance = 0.0;
		for(int feature = 0; feature<pattern1.length;feature++) {
			double currentValue = Math.abs(pattern1[feature] - pattern2[feature]);
			distance +=currentValue;
		}
		return distance;
	}
	protected static double calculateMahalanobisDistance(double pattern1[], double pattern2[], int nrOfPatterns) {
		double distance = 0.0;
		for(int feature=0;feature<pattern1.length;feature++) {
			distance+=Math.pow(pattern1[feature] - pattern2[feature], nrOfPatterns);
		}
		return Math.pow(distance,(double)1/nrOfPatterns);
	}

}



